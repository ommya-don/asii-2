import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextRequest, NextResponse } from "next/server";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const SYSTEM_PROMPT = `You are an intelligent AI Assistant for a specialized procurement and material planning dashboard. 
Your expertise includes:
- Dashboard navigation and feature assistance
- Procurement support and vendor management
- Material planning and inventory optimization
- Explaining complex reports and data visualizations
- Cost optimization strategies for industrial projects
- Helping users with their profile and account settings
- General smart business assistance for project managers

Keep your responses professional, concise, and highly relevant to the project management and procurement context. 
If a user asks about features not related to this dashboard, politely redirect them back to the dashboard's capabilities.`;

export async function POST(req: NextRequest) {
  try {
    const { message, history } = await req.json();

    if (!message || typeof message !== "string") {
      return NextResponse.json(
        { error: "Message is required and must be a string." },
        { status: 400 }
      );
    }

    if (!process.env.GEMINI_API_KEY) {
      console.error("GEMINI_API_KEY is not configured");
      return NextResponse.json(
        { error: "AI service is currently unavailable. Please configure the API key." },
        { status: 500 }
      );
    }

    // Prepare chat history for Gemini format
    // Gemini expects history in format: [{ role: 'user' | 'model', parts: [{ text: string }] }]
    const formattedHistory = (history || []).map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }],
    }));

    const chat = model.startChat({
      history: formattedHistory,
      generationConfig: {
        maxOutputTokens: 1000,
      },
    });

    // Send the message with the system prompt context if it's the first message or integrated
    // For simplicity in this implementation, we'll prepend the system prompt context to the first message 
    // or just use it as a base. Gemini 1.5 Flash handles instructions well.
    const prompt = history?.length === 0 
      ? `${SYSTEM_PROMPT}\n\nUser: ${message}`
      : message;

    const result = await chat.sendMessage(prompt);
    const response = await result.response;
    const text = response.text();

    return NextResponse.json({ reply: text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json(
      { error: "An error occurred while processing your request. Please try again later." },
      { status: 500 }
    );
  }
}
