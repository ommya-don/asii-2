"use client";

import React from "react";
import { AIChat } from "@/components/ai-chat";
import { Sparkles, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AIChatPage() {
  return (
    <div className="flex flex-col h-[calc(100vh-140px)] space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            AI Assistant
            <Sparkles className="h-6 w-6 text-primary" />
          </h1>
          <p className="text-muted-foreground mt-1">
            Get instant help with procurement, material planning, and dashboard insights.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1 overflow-hidden">
        <div className="lg:col-span-3 h-full overflow-hidden rounded-xl border border-border shadow-sm">
          <AIChat />
        </div>
        
        <div className="hidden lg:flex flex-col gap-4">
          <Alert className="bg-primary/5 border-primary/20">
            <Info className="h-4 w-4 text-primary" />
            <AlertTitle className="text-primary font-semibold">How to use</AlertTitle>
            <AlertDescription className="text-xs text-muted-foreground">
              Type your questions in the chat box. Our AI is trained on your project data to provide specific insights.
            </AlertDescription>
          </Alert>

          <div className="rounded-xl border border-border p-4 space-y-3 bg-muted/30">
            <h3 className="font-semibold text-sm">Suggested Topics</h3>
            <ul className="space-y-2">
              {[
                "Analyze material costs",
                "Vendor performance summary",
                "Project timeline overview",
                "Help with dashboard settings",
                "Cost optimization tips"
              ].map((topic) => (
                <li key={topic} className="text-xs flex items-center gap-2 text-muted-foreground">
                  <div className="h-1 w-1 rounded-full bg-primary" />
                  {topic}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-auto p-4 rounded-xl bg-gradient-to-br from-primary/10 to-transparent border border-primary/10">
            <p className="text-[10px] uppercase tracking-wider font-bold text-primary/70 mb-1">Model Status</p>
            <p className="text-xs font-medium">Gemini 1.5 Flash</p>
            <div className="flex items-center gap-1.5 mt-2">
              <div className="h-2 w-2 rounded-full bg-emerald-500" />
              <span className="text-[10px] text-muted-foreground">Operational & Secure</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
